# xbmc-confreaks

[Confreaks](http://www.confreaks.com) is a great resource for watching Ruby presentations from conferences around the world; [XBMC](http://www.xbmc.org) is a powerful media player which you can use to enjoy them from the comfort of you sofa.

## Usage

Just download a release from `releases`, and use 'Install from zip file' in XBMC -> System -> Addons.

Please note that this addon has only been tested with XBMC 11.0 Eden.

## Acknowledgements

This plugin uses [xbmcswift2](http://github.com/jbeluch/xbmcswift2), a "A micro framework to enable rapid development of XBMC plugins". Thanks to Jonathan Beluch for this.