# Confreaks Plugin Development Notes

Install PIP (http://pypi.python.org/pypi/pip)

* `$ sudo easy_install pip`


Picking up [xbmcswift2](http://www.xbmcswift.com/en/latest/installation.html) tutorial, install virtualenv:

* `$ sudo pip install virtualenv`
* `$ sudo pip install virtualenvwrapper`
* Add line to `~/.bash_profile`: `source /usr/local/bin/virtualenvwrapper.sh`
* `$ source ~/.bash_profile`
* `$ pip install -e git+git://github.com/jbeluch/xbmcswift2#egg=xbmcswift2`

Create plugin:

* `xbmcswift2 create`
* `xbmcwsift2 run`